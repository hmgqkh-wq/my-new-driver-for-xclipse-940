# Exynos Xclipse 940 — Advanced Custom Driver Repo (Ready-to-drop)

This repository is a full, ready-to-inspect and extend **prototype** of a revolutionary user-space driver wrapper tuned for Exynos 2400 / Xclipse 940, packaged for Winlator.  

What this repo includes:
- Vulkan ICD manifest for loader (icd.json).
- Vulkan interposer + ICD scaffolding (user-space shared library).
- Full CPU BC1–BC7 decoder (`src/bc_emulate.c`) optimized.
- GPU BC decode compute shader sources (`assets/shaders/bc_decode.comp.glsl`).
- SPIR-V build & optimization pipeline scripts (uses glslc and spirv-opt if available).
- Shader optimizer passes scaffolding (`src/shader_optimizer.cpp`) invoking `spirv-opt` or a fallback.
- LLVM-based JIT scaffolding (src/jit/) with description — requires LLVM toolchain to enable.
- Panfrost/Gallium-like modular driver layout inspiration under `src/driver/` (abstraction layers).
- Packaging scripts that assemble Winlator-compatible tar including ICD JSON and libs.
- `packaging/winlator_driver.json` suitable for some Winlator versions.

**Important:** This is a user-space wrapper (no root). To produce final .so for Android you must build with Android NDK (scripts provided). SPIR-V compilation requires `glslc` and `spirv-opt` installed on your build machine or included in CI.

See `docs/` for design notes and tuning recommendations for Xclipse 940.

