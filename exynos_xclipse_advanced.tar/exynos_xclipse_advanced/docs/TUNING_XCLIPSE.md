# Tuning recommendations for Xclipse 940

- Workgroup sizes: 8x8 and 16x8 are good starting points.
- Use subgroup-aware optimizations and minimize divergent branches.
- Pre-warm shader cache on first run to avoid stuttering.
