# Design notes — Advanced optimizations applied

Key design choices implemented in this repo:
- Vulkan ICD + interposer: allow Winlator to load our user-space driver library via driver manifest (icd.json).
- Shader pipeline: GLSL -> SPIR-V (glslc) -> spirv-opt (passes configurable) -> optional binary cache.
- Expanded optimizer passes: `--eliminate-dead-code`, `--inline-entry-points-exhaustive`, `--unify-duplicate-ids`, `--aggressive-inline` when perf mode=aggressive.
- BC1–BC7 GPU decode shader: a single combined compute shader with workgroup tuning, subgroup-friendly arithmetic, designed for RDNA3-derived Xclipse 940 (subgroup size 32 typical on RDNA? RDNA uses wave32 on some, but mobile may differ). Use env var `EXY_WORKGROUP` to tune.
- LLVM-based shader JIT scaffold: a system to generate specialized kernels at runtime using LLVM ORC JIT (disabled by default; requires linking libLLVM).
- Panfrost/Gallium-like architecture: modular driver layers (frontend, compiler, backend) to ease future integration into Mesa or reuse of Gallium concepts.
- Binary packaging: artifacts include driver libs, shaders (SPV), and a driver manifest for Winlator.

Security and compatibility:
- Library does not require root; uses standard Vulkan loader ICD mechanism.
- Binary cache stored under `/data/local/tmp/exynostools_cache` by default; override with `EXYNOSTOOLS_CACHE_DIR`.
