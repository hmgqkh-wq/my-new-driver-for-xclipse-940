// bc_shim.cpp - glue between driver and bc_emulate
#include "bc_shim.h"
#include <stdio.h>
int decode_texture_cpu(const unsigned char* data, size_t size, unsigned char* out, int w, int h, int fmt) {
    extern int decode_bc_to_rgba8(const uint8_t*, size_t, uint8_t*, int, int, int);
    return decode_bc_to_rgba8(data, size, out, w, h, fmt);
}
