#pragma once
int decode_texture_cpu(const unsigned char* data, size_t size, unsigned char* out, int w, int h, int fmt);
