// interposer.cpp - simplified interposer and ICD entry points
#include <vulkan/vulkan.h>
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>

extern "C" VkResult vkEnumerateInstanceExtensionProperties(const char* pLayerName, uint32_t* pPropertyCount, VkExtensionProperties* pProperties) {
    if (pPropertyCount) *pPropertyCount = 0;
    return VK_SUCCESS;
}

extern "C" const char* exynostools_icd_version() {
    return "exynostools-1.0";
}
