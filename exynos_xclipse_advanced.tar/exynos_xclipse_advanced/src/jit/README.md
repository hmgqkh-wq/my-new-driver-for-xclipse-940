LLVM JIT scaffold

This folder contains scaffolding for integrating an LLVM-based shader JIT.
It is disabled by default. To enable:
- Install LLVM development (libLLVM) matching your platform.
- Implement runtime compilation of SPIR-V or HLSL -> LLVM IR -> native code via ORC JIT.

We provide a conceptual example and API surface in src/jit/api.h and api.cpp to hook into the driver pipeline.
