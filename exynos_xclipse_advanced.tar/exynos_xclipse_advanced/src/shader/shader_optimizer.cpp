#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <unistd.h>

// Invoke spirv-opt if present; otherwise no-op
bool optimize_spirv_file(const std::string& in, const std::string& out, const std::string& flags) {
    const char* spirv_opt = getenv("SPIRV_OPT");
    if (!spirv_opt) spirv_opt = "spirv-opt";
    std::string cmd = std::string(spirv_opt) + " " + flags + " -o " + out + " " + in + " 2>/tmp/spirv_opt.log";
    int rc = system(cmd.c_str());
    return (rc == 0);
}
