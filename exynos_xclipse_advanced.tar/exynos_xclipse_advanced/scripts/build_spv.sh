#!/usr/bin/env bash
set -euo pipefail
SHADER_SRC=assets/shaders/bc_decode.comp.glsl
OUT=assets/shaders/bc_decode.spv
if command -v glslc >/dev/null 2>&1; then
  glslc -fshader-stage=compute -o $OUT $SHADER_SRC
  echo "Compiled SPV -> $OUT"
else
  echo "glslc not found. Install shaderc (glslc) to compile SPIR-V."
  exit 1
fi
