#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
PKG=$ROOT/artifacts/exynostools_full.tar
rm -f $PKG
mkdir -p $(dirname $PKG)
PKG_DIR=$(mktemp -d)
mkdir -p $PKG_DIR/usr/lib $PKG_DIR/usr/share/exynostools/shaders $PKG_DIR/etc
# copy files
cp -r assets/shaders $PKG_DIR/usr/share/exynostools/
cp packaging/icd.json $PKG_DIR/etc/
# copy library if built
if [ -f build/libexynostools.so ]; then cp build/libexynostools.so $PKG_DIR/usr/lib/; fi
tar -C $PKG_DIR -cf $PKG .
echo "Package created: $PKG"
