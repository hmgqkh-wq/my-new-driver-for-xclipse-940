#!/usr/bin/env bash
set -euo pipefail
bash scripts/build_spv.sh || true
bash scripts/package_full.sh
